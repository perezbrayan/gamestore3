import React from 'react';
import FortniteShop from '../components/FortniteShop';

const FortniteShopPage = () => {
  return (
    <div className="pt-20">
      <FortniteShop />
    </div>
  );
};

export default FortniteShopPage;
