import React, { useEffect, useState } from 'react';
import { ChevronRight, Star, TrendingUp, Zap, ShoppingCart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getDailyShop, FortniteItem } from '../services/fortniteApi';

const Home = () => {
  const [featuredItems, setFeaturedItems] = useState<FortniteItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeaturedItems = async () => {
      try {
        const shopItems = await getDailyShop();
        const filteredItems = shopItems
          .filter(item => {
            const lowerDisplayType = item.displayType?.toLowerCase() || '';
            const lowerMainId = item.mainId?.toLowerCase() || '';
            const lowerDisplayName = item.displayName?.toLowerCase() || '';
            const lowerDescription = item.displayDescription?.toLowerCase() || '';
            
            const musicKeywords = ['track', 'música', 'music', 'jam', 'beat', 'remix', 'sonido', 'sound'];
            return !musicKeywords.some(keyword => 
              lowerDisplayType.includes(keyword) || 
              lowerMainId.includes(keyword) || 
              lowerDisplayName.includes(keyword) || 
              lowerDescription.includes(keyword)
            );
          })
          .slice(0, 4);
        
        setFeaturedItems(filteredItems);
      } catch (error) {
        console.error('Error fetching Fortnite items:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchFeaturedItems();
  }, []);

  const getBestImage = (item: FortniteItem) => {
    if (item.displayAssets?.[0]?.url) {
      return item.displayAssets[0].url;
    }
    return item.displayAssets?.[0]?.background || '';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section - Modernizado */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-primary-900 to-gray-900">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.1)_0%,transparent_100%)] opacity-50"></div>
          {/* Patrón de fondo animado */}
          <div className="absolute inset-0 opacity-30">
            <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.1)_25%,rgba(255,255,255,0.1)_50%,transparent_50%,transparent_75%,rgba(255,255,255,0.1)_75%)] bg-[length:64px_64px] animate-[gradient_3s_linear_infinite]"></div>
          </div>
        </div>
        <div className="container mx-auto px-4 relative z-10 pt-20">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-6xl md:text-7xl font-bold text-white mb-8 leading-tight">
              Tu Destino Gaming
              <span className="block text-primary-400">Definitivo</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-12 leading-relaxed">
              Explora nuestra colección de juegos, items exclusivos y contenido premium para elevar tu experiencia gaming al siguiente nivel.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                to="/fortnite-shop"
                className="px-8 py-4 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-semibold transition-all duration-300 flex items-center justify-center gap-2 transform hover:scale-105"
              >
                <ShoppingCart className="w-5 h-5" />
                Explorar Tienda
              </Link>
              <button className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold backdrop-blur-sm transition-all duration-300 flex items-center justify-center gap-2 transform hover:scale-105">
                Ver Ofertas
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
        {/* Decorative circles */}
        <div className="absolute -top-20 -right-20 w-96 h-96 bg-primary-500/20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-primary-500/20 rounded-full blur-3xl"></div>
      </section>

      {/* Features Section - Mejorado */}
      <section className="py-24 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">¿Por qué elegirnos?</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Descubre las ventajas que nos hacen únicos en el mundo gaming
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
              <div className="w-14 h-14 bg-primary-600/10 rounded-xl flex items-center justify-center mb-6">
                <Zap className="w-7 h-7 text-primary-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Entrega Instantánea</h3>
              <p className="text-gray-600 leading-relaxed">
                Recibe tus items y códigos de juego al instante después de tu compra, sin esperas ni complicaciones.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
              <div className="w-14 h-14 bg-primary-600/10 rounded-xl flex items-center justify-center mb-6">
                <Star className="w-7 h-7 text-primary-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Items Exclusivos</h3>
              <p className="text-gray-600 leading-relaxed">
                Accede a contenido único y elementos especiales que harán destacar tu experiencia de juego.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
              <div className="w-14 h-14 bg-primary-600/10 rounded-xl flex items-center justify-center mb-6">
                <TrendingUp className="w-7 h-7 text-primary-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Mejores Precios</h3>
              <p className="text-gray-600 leading-relaxed">
                Garantizamos los mejores precios del mercado con ofertas exclusivas y descuentos especiales.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Fortnite Items - Renovado */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Items Destacados de Fortnite</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Explora nuestra selección de items más populares y exclusivos
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {loading ? (
              Array(4).fill(0).map((_, index) => (
                <div key={index} className="animate-pulse">
                  <div className="bg-gray-200 h-80 rounded-2xl mb-4"></div>
                  <div className="bg-gray-200 h-6 w-3/4 rounded mb-2"></div>
                  <div className="bg-gray-200 h-4 w-1/2 rounded mb-2"></div>
                  <div className="bg-gray-200 h-4 w-1/4 rounded"></div>
                </div>
              ))
            ) : (
              featuredItems.map((item) => (
                <div key={item.mainId} className="group">
                  <div className="relative overflow-hidden rounded-2xl mb-4 bg-gray-100">
                    {getBestImage(item) ? (
                      <img 
                        src={getBestImage(item)}
                        alt={item.displayName}
                        className="w-full h-80 object-cover transform group-hover:scale-110 transition-transform duration-500"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-full h-80 bg-gradient-to-br from-primary-600 to-primary-900 flex items-center justify-center p-4 text-center">
                        <span className="text-white font-semibold">{item.displayName}</span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300">
                      <div className="absolute bottom-4 left-4 right-4">
                        <Link 
                          to="/fortnite-shop" 
                          className="w-full px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-semibold transition-all duration-300 flex items-center justify-center gap-2"
                        >
                          <ShoppingCart className="w-5 h-5" />
                          Ver en Tienda
                        </Link>
                      </div>
                    </div>
                  </div>
                  <h3 className="text-xl font-bold mb-2 group-hover:text-primary-600 transition-colors duration-300">
                    {item.displayName}
                  </h3>
                  <p className="text-gray-600 mb-2">{item.mainType}</p>
                  <p className="text-primary-600 font-bold text-lg">{item.price.finalPrice} V-Bucks</p>
                </div>
              ))
            )}
          </div>
        </div>
        {/* Background decoration */}
        <div className="absolute top-0 left-0 w-full h-40 bg-gradient-to-b from-gray-50 to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full h-40 bg-gradient-to-t from-gray-50 to-transparent"></div>
      </section>

      {/* CTA Section - Renovado */}
      <section className="py-24 bg-gradient-to-br from-gray-900 via-primary-900 to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.1)_0%,transparent_100%)] opacity-50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-5xl font-bold mb-6 text-white">
              ¿Listo para mejorar tu experiencia?
            </h2>
            <p className="text-xl mb-12 text-white/90 leading-relaxed">
              Únete a nuestra comunidad y obtén acceso a ofertas exclusivas, eventos especiales y contenido premium.
            </p>
            <Link
              to="/fortnite-shop"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-primary-900 rounded-xl font-semibold 
                hover:bg-primary-50 transition-all duration-300 transform hover:scale-105
                shadow-lg hover:shadow-white/25"
            >
              Comenzar Ahora
              <ChevronRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
      </section>
    </div>
  );
};

export default Home;