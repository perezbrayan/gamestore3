import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ShoppingCart, Search, User, Gamepad2, Home, Gift, Sparkles, Tag } from 'lucide-react';
import logo from '../assets/logo.svg';

interface NavLinkProps {
  to: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const NavLink = ({ to, icon, children }: NavLinkProps) => {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link
      to={to}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 ${
        isActive 
          ? 'text-primary-600 bg-primary-50 font-medium' 
          : 'text-gray-700 hover:text-primary-600 hover:bg-gray-50'
      }`}
    >
      {icon}
      <span>{children}</span>
    </Link>
  );
};

const SearchBar = () => (
  <div className="relative flex-1 max-w-xl">
    <input
      type="text"
      placeholder="Buscar items..."
      className="w-full px-4 py-2.5 pl-11 rounded-xl border border-gray-200 focus:border-primary-600 focus:ring-2 focus:ring-primary-100 focus:outline-none transition-all duration-200"
    />
    <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
  </div>
);

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartCount] = useState(0);

  const navLinks = [
    { to: "/", icon: <Home className="w-5 h-5" />, label: "Inicio" },
    { to: "/tienda", icon: <ShoppingCart className="w-5 h-5" />, label: "Tienda" },
    { to: "/fortnite-shop", icon: <Gamepad2 className="w-5 h-5" />, label: "Fortnite" },
    { to: "/novedades", icon: <Sparkles className="w-5 h-5" />, label: "Novedades" },
    { to: "/ofertas", icon: <Tag className="w-5 h-5" />, label: "Ofertas" },
    { to: "/regalos", icon: <Gift className="w-5 h-5" />, label: "Regalos" },
  ];

  return (
    <header className="w-full fixed top-0 z-50 bg-white shadow-md">
      <nav className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link 
            to="/" 
            className="flex-shrink-0 flex items-center gap-2"
          >
            <img src={logo} alt="GameStore" className="h-10 w-auto" />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-2">
            {navLinks.map((link) => (
              <NavLink key={link.to} to={link.to} icon={link.icon}>
                {link.label}
              </NavLink>
            ))}
          </div>

          {/* Search and Actions */}
          <div className="hidden lg:flex items-center gap-4">
            <SearchBar />
            
            {/* User Menu */}
            <button className="p-2.5 hover:bg-gray-100 rounded-lg transition-all duration-200">
              <User className="w-5 h-5 text-gray-700" />
            </button>
            
            {/* Cart */}
            <button className="p-2.5 hover:bg-gray-100 rounded-lg transition-all duration-200 relative">
              <ShoppingCart className="w-5 h-5 text-gray-700" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-all duration-200"
          >
            {isMenuOpen ? (
              <X className="w-6 h-6 text-gray-700" />
            ) : (
              <Menu className="w-6 h-6 text-gray-700" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-gray-100">
            <div className="space-y-2">
              <div className="px-2 pb-4">
                <SearchBar />
              </div>
              {navLinks.map((link) => (
                <NavLink key={link.to} to={link.to} icon={link.icon}>
                  {link.label}
                </NavLink>
              ))}
              <div className="border-t border-gray-100 mt-4 pt-4 space-y-2">
                <Link 
                  to="/perfil" 
                  className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-primary-600 hover:bg-gray-50 rounded-lg transition-all duration-200"
                >
                  <User className="w-5 h-5" />
                  <span>Mi Perfil</span>
                </Link>
                <Link 
                  to="/carrito" 
                  className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-primary-600 hover:bg-gray-50 rounded-lg transition-all duration-200"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span>Carrito</span>
                  {cartCount > 0 && (
                    <span className="ml-auto bg-primary-600 text-white text-xs px-2 py-1 rounded-full">
                      {cartCount}
                    </span>
                  )}
                </Link>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Navbar;