la peticion debe ser asi : 

API Key (Authorization header)
eafc4329-54aeed01-a90cd52b-f749534c
 y obtener la tienda diaria  de fortnite  con la siguiente url:

Get daily shop
List all items currently in the shop
List of supported languages: en, ar, de, es, es-419, fr, it, ja, ko, pl, pt-BR, ru, tr, zh-CN, zh-Hant

GET https://fortniteapi.io/v2/shop?lang=en
